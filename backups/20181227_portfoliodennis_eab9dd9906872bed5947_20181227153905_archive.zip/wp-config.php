<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wpdb');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'C-N$^#Lvs+]4[H^[o.28>!kHa,++uujN;PTdAJ,wq&@GD0R#Er;.@=HAu^$rqbdv');
define('SECURE_AUTH_KEY',  'EFgxglO1SWD~(LlK/Dt>f3]Q-VZWA2bfdO?<b!OE[[4?1_(NrC;ZE<Sy6N^6_,M(');
define('LOGGED_IN_KEY',    'J`]Y|{:K~?H|}pm@.A:SHZ9wb[K.b#n]GN&>1<Vwdg?*,*qUX:EUt#auo`Up_1p*');
define('NONCE_KEY',        '2ivOY`m88V2l*OEX@ j!=6<JT$x0dx?d`T82}uD<[>KjETdrlBy<?wy &OgH1W$a');
define('AUTH_SALT',        'P7{CAAdcRlIc4)8o{kzp*q4w73FkIH|!$Ay0x6T{JM))J=*: bT-NgU&EW+Bfa2>');
define('SECURE_AUTH_SALT', ' ?%X39v<Lo4;2M}. [NnB^/PR~Kl29}CA.nz6YR6M}|mx)@<222C^VPp&$/=#{[4');
define('LOGGED_IN_SALT',   'gK?}3)H3[:TELHwT<Ijc&RHBv0FlfO>}SSr&@,S}oVQrY3`IP_i028dB+`J3>U88');
define('NONCE_SALT',       'mh?dgez^tG[iB&i5mH7Mz5#&[)qYgk>I[kR_afkE*GAfl71==~H6;IHn6o5zu%Tm');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
